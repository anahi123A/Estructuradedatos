#pragma once
#include "iostream"
#include "Matriz.h"

namespace MATRIZZ {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Matriz M1;
	int posf=0;
	int posc=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnDefinir1;
	protected: 
	private: System::Windows::Forms::Button^  btnDefinir2;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::TextBox^  txtcolumna;
	private: System::Windows::Forms::TextBox^  txtnumero;
	private: System::Windows::Forms::DataGridView^  Grilla;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnDefinir1 = (gcnew System::Windows::Forms::Button());
			this->btnDefinir2 = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->txtnumero = (gcnew System::Windows::Forms::TextBox());
			this->Grilla = (gcnew System::Windows::Forms::DataGridView());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// btnDefinir1
			// 
			this->btnDefinir1->Location = System::Drawing::Point(290, 33);
			this->btnDefinir1->Name = L"btnDefinir1";
			this->btnDefinir1->Size = System::Drawing::Size(75, 23);
			this->btnDefinir1->TabIndex = 0;
			this->btnDefinir1->Text = L"Definir";
			this->btnDefinir1->UseVisualStyleBackColor = true;
			this->btnDefinir1->Click += gcnew System::EventHandler(this, &Form1::btnDefinir1_Click);
			// 
			// btnDefinir2
			// 
			this->btnDefinir2->Location = System::Drawing::Point(290, 77);
			this->btnDefinir2->Name = L"btnDefinir2";
			this->btnDefinir2->Size = System::Drawing::Size(75, 23);
			this->btnDefinir2->TabIndex = 1;
			this->btnDefinir2->Text = L"Definir";
			this->btnDefinir2->UseVisualStyleBackColor = true;
			this->btnDefinir2->Click += gcnew System::EventHandler(this, &Form1::btnDefinir2_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(290, 118);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 2;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(99, 36);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(23, 13);
			this->label1->TabIndex = 3;
			this->label1->Text = L"Fila";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(99, 80);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(48, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Columna";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(99, 123);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Numero";
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(166, 33);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(100, 20);
			this->txtfila->TabIndex = 6;
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(166, 77);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(100, 20);
			this->txtcolumna->TabIndex = 7;
			// 
			// txtnumero
			// 
			this->txtnumero->Location = System::Drawing::Point(166, 116);
			this->txtnumero->Name = L"txtnumero";
			this->txtnumero->Size = System::Drawing::Size(100, 20);
			this->txtnumero->TabIndex = 8;
			// 
			// Grilla
			// 
			this->Grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla->Location = System::Drawing::Point(102, 162);
			this->Grilla->Name = L"Grilla";
			this->Grilla->Size = System::Drawing::Size(299, 135);
			this->Grilla->TabIndex = 9;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(472, 301);
			this->Controls->Add(this->Grilla);
			this->Controls->Add(this->txtnumero);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir2);
			this->Controls->Add(this->btnDefinir1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir1_Click(System::Object^  sender, System::EventArgs^  e) {

				 int fila;
				 fila=System::Convert::ToInt32(txtfila->Text);
				 M1.Set_fila(fila);
				 Grilla->RowCount=fila;

			 }
private: System::Void btnDefinir2_Click(System::Object^  sender, System::EventArgs^  e) {
	
		 int columna;
		 columna=System::Convert::ToInt32(txtcolumna->Text);
		 M1.Set_columna(columna);
		 Grilla->ColumnCount=columna;
		 
		 
		 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
		
		int elemento,columna,fila;
		elemento=System::Convert::ToInt32(txtnumero->Text);
		//columna=System::Convert::ToInt32(txtcolumna->Text);
		M1.Set_MAT(posf,posc,elemento);
		//{for(int posf=0;posf <fila;posf++)
		//{for(int posc=0;posc<columna;posc++)
		//{ 
			
		Grilla->Rows[posf++]->Cells[posc++]->Value=elemento;
		
		//}
		//}
		//}
		 }
};
}

