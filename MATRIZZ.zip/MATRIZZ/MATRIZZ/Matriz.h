#pragma once
#define N 20
#define M 20
 class Matriz
{ private:
 int fila;
 int columna;
 int MAT[N][M];


public:
	Matriz(void);

	int Get_fila();
	void Set_fila(int f);
	int Get_columna();
	void Set_columna(int c);
	int Get_MAT(int posf, int posc);
	void Set_MAT(int posf, int posc, int ele);

};

