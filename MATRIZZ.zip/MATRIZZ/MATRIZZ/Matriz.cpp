#include "StdAfx.h"
#include "Matriz.h"

Matriz::Matriz(void)
{
	fila=0;
	columna=0;
	MAT[N][M]=0;
}

int Matriz::Get_fila()
	{return fila;}
void Matriz::Set_fila(int f)
	{fila=f;}
int Matriz::Get_columna()
	{return columna;}
void Matriz::Set_columna(int c)
	{columna=c;}
int Matriz::Get_MAT(int posf, int posc)
	{return MAT[posf][posc];
	}
void Matriz::Set_MAT(int posf, int posc, int ele)
    { MAT[posf][posc]=ele;
	}