#pragma once

namespace Areadelrombo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtmayor;
	private: System::Windows::Forms::TextBox^  txtmenor;
	private: System::Windows::Forms::TextBox^  txtarea;
	private: System::Windows::Forms::Button^  btbCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtmayor = (gcnew System::Windows::Forms::TextBox());
			this->txtmenor = (gcnew System::Windows::Forms::TextBox());
			this->txtarea = (gcnew System::Windows::Forms::TextBox());
			this->btbCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(43, 36);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(36, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Mayor";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(46, 74);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(37, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Menor";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(46, 111);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(29, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Area";
			// 
			// txtmayor
			// 
			this->txtmayor->Location = System::Drawing::Point(164, 36);
			this->txtmayor->Name = L"txtmayor";
			this->txtmayor->Size = System::Drawing::Size(100, 20);
			this->txtmayor->TabIndex = 3;
			// 
			// txtmenor
			// 
			this->txtmenor->Location = System::Drawing::Point(164, 74);
			this->txtmenor->Name = L"txtmenor";
			this->txtmenor->Size = System::Drawing::Size(100, 20);
			this->txtmenor->TabIndex = 4;
			// 
			// txtarea
			// 
			this->txtarea->Location = System::Drawing::Point(164, 111);
			this->txtarea->Name = L"txtarea";
			this->txtarea->Size = System::Drawing::Size(100, 20);
			this->txtarea->TabIndex = 5;
			// 
			// btbCalcular
			// 
			this->btbCalcular->Location = System::Drawing::Point(108, 166);
			this->btbCalcular->Name = L"btbCalcular";
			this->btbCalcular->Size = System::Drawing::Size(75, 23);
			this->btbCalcular->TabIndex = 6;
			this->btbCalcular->Text = L"Calcular";
			this->btbCalcular->UseVisualStyleBackColor = true;
			this->btbCalcular->Click += gcnew System::EventHandler(this, &Form1::btbCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btbCalcular);
			this->Controls->Add(this->txtarea);
			this->Controls->Add(this->txtmenor);
			this->Controls->Add(this->txtmayor);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btbCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 int mayor,menor,Area;
				 mayor = System::Convert::ToInt32(txtmayor->Text);
				 menor = System::Convert::ToInt32(txtmenor->Text);
			     Area = (mayor * menor)/ 2;
				 txtarea->Text = Area.ToString();
			 }
};
}

