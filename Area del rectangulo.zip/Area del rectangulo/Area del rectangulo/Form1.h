#pragma once

namespace Areadelrectangulo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtbase;
	private: System::Windows::Forms::TextBox^  txtaltura;
	private: System::Windows::Forms::Button^  btbCalcular;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtarea;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtbase = (gcnew System::Windows::Forms::TextBox());
			this->txtaltura = (gcnew System::Windows::Forms::TextBox());
			this->btbCalcular = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtarea = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(88, 90);
			this->label1->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(52, 24);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Base";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(88, 172);
			this->label2->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(58, 24);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Altura";
			// 
			// txtbase
			// 
			this->txtbase->Location = System::Drawing::Point(220, 90);
			this->txtbase->Margin = System::Windows::Forms::Padding(6, 6, 6, 6);
			this->txtbase->Name = L"txtbase";
			this->txtbase->Size = System::Drawing::Size(180, 29);
			this->txtbase->TabIndex = 2;
			// 
			// txtaltura
			// 
			this->txtaltura->Location = System::Drawing::Point(220, 166);
			this->txtaltura->Margin = System::Windows::Forms::Padding(6, 6, 6, 6);
			this->txtaltura->Name = L"txtaltura";
			this->txtaltura->Size = System::Drawing::Size(180, 29);
			this->txtaltura->TabIndex = 3;
			// 
			// btbCalcular
			// 
			this->btbCalcular->Location = System::Drawing::Point(220, 325);
			this->btbCalcular->Margin = System::Windows::Forms::Padding(6, 6, 6, 6);
			this->btbCalcular->Name = L"btbCalcular";
			this->btbCalcular->Size = System::Drawing::Size(138, 42);
			this->btbCalcular->TabIndex = 4;
			this->btbCalcular->Text = L"Calcular";
			this->btbCalcular->UseVisualStyleBackColor = true;
			this->btbCalcular->Click += gcnew System::EventHandler(this, &Form1::btbCalcular_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(94, 249);
			this->label3->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(50, 24);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Area";
			// 
			// txtarea
			// 
			this->txtarea->Location = System::Drawing::Point(220, 249);
			this->txtarea->Margin = System::Windows::Forms::Padding(6, 6, 6, 6);
			this->txtarea->Name = L"txtarea";
			this->txtarea->Size = System::Drawing::Size(180, 29);
			this->txtarea->TabIndex = 6;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(11, 24);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(521, 482);
			this->Controls->Add(this->txtarea);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btbCalcular);
			this->Controls->Add(this->txtaltura);
			this->Controls->Add(this->txtbase);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(6, 6, 6, 6);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btbCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 int base,altura,Area;
				 base = System::Convert::ToInt32(txtbase->Text);
				 altura = System::Convert::ToInt32(txtaltura->Text);
			     Area = base * altura;
				 txtarea->Text = Area.ToString();


			 }
};
}

