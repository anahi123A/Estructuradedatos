// ejemplopiladinamica.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream> 
#include "Nodo.h" //Se incluye a la clase Nodo
using namespace std; 
void Apilar( Nodo *&cima){ //Punteros enviados por referencia      
    Nodo *Elemento = new Nodo; //Creacion del nodo      
    if(cima == NULL){ 
      cima = Elemento; //Le asigno la direccion del primer nodo          
        cout<<"Codigo: "; cin>>Elemento->dato.Codigo; 
        cout<<"Nombres: "; cin>>Elemento->dato.Nombre; 
        cout<<"Carrera: "; cin>>Elemento->dato.Carrera; 
         
         
    }else{ 
         
       cima->puntero = Elemento; //Asigno el puntero del anterior elemento al nuevo

       cima = Elemento; //Cambio la direccion del ultimo nodo creado 

        cout<<"Codigo: "; cin>>Elemento->dato.Codigo; 
        cout<<"Nombres: "; cin>>Elemento->dato.Nombre; 
        cout<<"Carrera: "; cin>>Elemento->dato.Carrera; cout<<endl; 
         
    } 
     
     } void Desapilar(Nodo *&cima){ 
    if(cima != NULL){ 
        cout<<"Codigo: "<<cima->dato.Codigo<<endl; 
        cout<<"Nombres: "<<cima->dato.Nombre<<endl; 
        cout<<"Carrera: "<<cima->dato.Carrera<<endl; 
      cima = cima->puntero;
	  cima--;// Cambio Inicio al siguiente nodo
    }else{ 
        cout<<"La pila se encuentra vacia"<<endl; 
    } } int main (int argc, char *argv[]) { 
    Nodo *cima = NULL ; //Punteros libres para el manejo de la cola
    int opc = 0, respuesta = 0; 
    do{ 
        cout<<"1. LA PILA ESTA VACIA?"<<endl; 
        cout<<"2. APILAR"<<endl; 
        cout<<"3. DESAPILAR"<<endl; 
        cout<<"4. FINALIZAR"<<endl; 
        cout<<"Opcion: "; cin>>opc; 
         
         
        switch (opc){ 
        case 1 : 
            if( cima == NULL) 
                cout<<"La pila se encuentra vacia"<<endl; 
            else 
                cout<<"Existe elemento(s) dentro de la pila"<<endl; 
            break; 
        case 2 : 
            Apilar(cima); 
            break; 
        case 3: 
            Desapilar(cima); 
            break ; 
             
        } 
         
    }while(opc != 4); 
     
     
    return 0; }
