#include "Stdafx.h"
#include "Concat.h"

#define M 10
#define N 20

Concat::Concat(void)
{vector[N]= 0;
tamano=0;

}



	int Concat::Get_tamano()
	{ return tamano;
	}
	void Concat::Set_tamano(int tam)
	{tamano=tam;
	}
    int Concat::Get_vector(int posicion)
	{return vector[posicion];
	}
	void Concat::Set_vector(int posicion,int elemento )
	{vector[posicion]=elemento;
	}
	bool Concat::vaciovector()
	{if(tamano==0)
	{return true;}
	else
	{return false;}
	}
	
	bool Concat::llenovector()
	{ if (tamano==(N-1))
	{return true;}
	else{return false;}

	}
	
	Concat Concat::Concatenar(Concat vector1, Concat vector2)
	{Concat vector3;
		vector3.tamano=vector1.tamano+vector2.tamano;
		for(int i=0; i<vector1.tamano;i++ )
		{vector3.vector[i]=vector1.vector[i];}
		for(int j=vector1.tamano;j<vector3.tamano;j++)

		{vector3.vector[j]=vector2.vector[j-vector1.tamano];
		}
		return vector3;
	}