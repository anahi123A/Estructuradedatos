#pragma once
#include "Concat.h"
#include <iostream>

namespace Concatenar {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Concat vector1, vector2, vector3;
	int posicion=0;
	int posicion1=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txttamano;
	protected: 

	private: System::Windows::Forms::TextBox^  txtdato;
	protected: 

	protected: 

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::DataGridView^  Grilla1;


	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridView^  Grilla2;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtdato1;
	private: System::Windows::Forms::TextBox^  txttamano1;


	private: System::Windows::Forms::DataGridView^  Grilla3;


	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::Button^  button6;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->txtdato = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->Grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtdato1 = (gcnew System::Windows::Forms::TextBox());
			this->txttamano1 = (gcnew System::Windows::Forms::TextBox());
			this->Grilla3 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button6 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla3))->BeginInit();
			this->SuspendLayout();
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(127, 38);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(100, 20);
			this->txttamano->TabIndex = 0;
			// 
			// txtdato
			// 
			this->txtdato->Location = System::Drawing::Point(127, 77);
			this->txtdato->Name = L"txtdato";
			this->txtdato->Size = System::Drawing::Size(100, 20);
			this->txtdato->TabIndex = 1;
			this->txtdato->TextChanged += gcnew System::EventHandler(this, &Form1::textBox2_TextChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(56, 38);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(56, 84);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(30, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Dato";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(267, 33);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Ingresar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(267, 79);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 5;
			this->button2->Text = L"Ingresar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// Grilla1
			// 
			this->Grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grilla1->Location = System::Drawing::Point(384, 12);
			this->Grilla1->Name = L"Grilla1";
			this->Grilla1->Size = System::Drawing::Size(215, 100);
			this->Grilla1->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Grilla2
			// 
			this->Grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->Grilla2->Location = System::Drawing::Point(384, 131);
			this->Grilla2->Name = L"Grilla2";
			this->Grilla2->Size = System::Drawing::Size(215, 100);
			this->Grilla2->TabIndex = 13;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(267, 208);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 12;
			this->button3->Text = L"Ingresar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(267, 165);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 11;
			this->button4->Text = L"Ingresar";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(56, 211);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(30, 13);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Dato";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(56, 165);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(46, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Tama�o";
			// 
			// txtdato1
			// 
			this->txtdato1->Location = System::Drawing::Point(127, 208);
			this->txtdato1->Name = L"txtdato1";
			this->txtdato1->Size = System::Drawing::Size(100, 20);
			this->txtdato1->TabIndex = 8;
			// 
			// txttamano1
			// 
			this->txttamano1->Location = System::Drawing::Point(127, 168);
			this->txttamano1->Name = L"txttamano1";
			this->txttamano1->Size = System::Drawing::Size(100, 20);
			this->txttamano1->TabIndex = 7;
			// 
			// Grilla3
			// 
			this->Grilla3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->Grilla3->Location = System::Drawing::Point(384, 251);
			this->Grilla3->Name = L"Grilla3";
			this->Grilla3->Size = System::Drawing::Size(215, 119);
			this->Grilla3->TabIndex = 20;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Column3";
			this->Column3->Name = L"Column3";
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(267, 294);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(75, 23);
			this->button6->TabIndex = 18;
			this->button6->Text = L"Concatenar";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(794, 382);
			this->Controls->Add(this->Grilla3);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->Grilla2);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtdato1);
			this->Controls->Add(this->txttamano1);
			this->Controls->Add(this->Grilla1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtdato);
			this->Controls->Add(this->txttamano);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {

	 int dato1;
			 dato1=System::Convert::ToInt32(txtdato->Text);
			 vector1.Set_vector(dato1, posicion);
			 Grilla1->Rows[posicion]->Cells[0]->Value=dato1;
			 posicion++;

			 }
private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

			int tam1;
			  tam1=System::Convert::ToInt32(txttamano->Text);
			   Grilla1->RowCount=tam1;
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {

			 	 int tam2;
			  tam2=System::Convert::ToInt32(txttamano1->Text);
			   Grilla2->RowCount=tam2;
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {

			  int dato2;
			 dato2=System::Convert::ToInt32(txtdato1->Text);
			 Grilla2->Rows[posicion1]->Cells[0]->Value=dato2;
			 posicion1++;

		 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
		int tam1,tam2,tam3;
			 tam1=System::Convert::ToInt32(txttamano->Text);
			  tam2=System::Convert::ToInt32(txttamano1->Text);

			  tam3=tam1+tam2;
			  vector3.Set_tamano(tam3);
			Grilla3->RowCount=vector3.Get_tamano();
			vector3=vector3.Concatenar(vector1,vector2);

			for(int i=0; i<vector3.Get_tamano();i++)
			{Grilla3->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(vector3.Get_vector(i));}

		 }
};
}

