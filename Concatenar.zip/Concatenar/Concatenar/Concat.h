#pragma once
#define M 10
#define N 20


 class Concat
{private:
  int vector[N];
    int tamano;
 
 


public:
	Concat(void);
	int Get_tamano();
	void Set_tamano(int tam);
    int Get_vector(int posicion);
	void Set_vector(int posicion,int elemento );
	bool llenovector();
	bool vaciovector();
	

	Concat Concatenar(Concat vector1, Concat vector2);


 };
 
