#include "StdAfx.h"
#include "Concatenar.h"


Concatenar::Concatenar(void)
{
	Vector1[n]= 0;
	Vector2[m]= 0;
	tamano=0;

}
int Concatenar::Get_tamano()
	{ return tamano;
	}

void Concatenar::Set_tamano(int tam)
	{ tamano=tam;
	}

	int Concatenar::Get_insertar(int pos)
	{ return insertar[pos];
	}
	void Concatenar::Set_insertar(int pos , int ele)
	{insertar[pos]=ele;
	}
	int Concatenar::Get_Vector1(int pos)
	{return Vector1[pos];
	}
    void Concatenar::Set_Vector1(int pos, int ele)
	{ Vector1[pos]=ele;

	}
	int Concatenar::Get_Vector2(int pos)
	{ return Vector2[pos];
	}
    void Concatenar::Set_Vector2(int pos, int ele)
	{Vector2[pos]=elem;
	}
	
	Concatenar concatenar (Concatenar Vector1, Concatenar vector2)
	{Concatenar Vector3;
	Vector3.tamano = Vector1.tamano+Vector2.tamano;
	
	for (int k=0; k<Vector1.tamano;k++)
	   { Vector3.V[k]=Vector1.V[k]; 
	   }
	   for (int i=vec1.tamano ; i<Vector3.tamano;i++)
	   {Vector3.V[i]=Vector2.V[i-Vector1.tamano]; 
	   }
	      
	   int aux;
	    for (int k=0; k<Vector3.tamano;k++)
  { for (int t=k+1; t<Vector3.tamano;t++)
   {  if (Vector3.V[t]< Vector3.V[k]);
      {aux = Vector3.V[k];
	   Vector3.V[k]= Vector3.V[t];
	   Vector3.V[t]=aux;
      }
   }
  }

 return Vector3;
	
	}