#pragma once
#define n 15
#define m 10

class Concatenar
{
private:
   int Vector1[n];
   int Vector2[m];
  
   int tamano;

public:
	Concatenar(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_insertar(int pos);
	void Set_insertar(int pos, int elmento);
	int Get_Vector1(int pos);
    void Set_Vector1(int pos, int ele);
	int Get_Vector2(int pos);
    void Set_Vector2(int pos, int ele);

	Concatenar concatenar (Concatenar Vector1, Concatenar Vector2);


};

