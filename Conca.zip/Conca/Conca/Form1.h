#pragma once
#include "Concatenar.h"
namespace Conca {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Concatenar V1;
		Concatenar V2;
		Concatenar C1;
	int pos =0;
	int pos2=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btntamano1;
	protected: 
	private: System::Windows::Forms::Button^  btntamano2;
	private: System::Windows::Forms::TextBox^  txttam1;
	private: System::Windows::Forms::TextBox^  txttam2;
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::DataGridView^  grilla2;




	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtinsertar;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  txtinsertar2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btntamano1 = (gcnew System::Windows::Forms::Button());
			this->btntamano2 = (gcnew System::Windows::Forms::Button());
			this->txttam1 = (gcnew System::Windows::Forms::TextBox());
			this->txttam2 = (gcnew System::Windows::Forms::TextBox());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtinsertar = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->txtinsertar2 = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			this->SuspendLayout();
			// 
			// btntamano1
			// 
			this->btntamano1->Location = System::Drawing::Point(244, 48);
			this->btntamano1->Name = L"btntamano1";
			this->btntamano1->Size = System::Drawing::Size(75, 23);
			this->btntamano1->TabIndex = 0;
			this->btntamano1->Text = L"Tama�o1";
			this->btntamano1->UseVisualStyleBackColor = true;
			this->btntamano1->Click += gcnew System::EventHandler(this, &Form1::btntamano1_Click);
			// 
			// btntamano2
			// 
			this->btntamano2->Location = System::Drawing::Point(244, 89);
			this->btntamano2->Name = L"btntamano2";
			this->btntamano2->Size = System::Drawing::Size(75, 23);
			this->btntamano2->TabIndex = 1;
			this->btntamano2->Text = L"Tama�o2";
			this->btntamano2->UseVisualStyleBackColor = true;
			this->btntamano2->Click += gcnew System::EventHandler(this, &Form1::btntamano2_Click);
			// 
			// txttam1
			// 
			this->txttam1->Location = System::Drawing::Point(129, 48);
			this->txttam1->Name = L"txttam1";
			this->txttam1->Size = System::Drawing::Size(100, 20);
			this->txttam1->TabIndex = 2;
			// 
			// txttam2
			// 
			this->txttam2->Location = System::Drawing::Point(129, 86);
			this->txttam2->Name = L"txttam2";
			this->txttam2->Size = System::Drawing::Size(100, 20);
			this->txttam2->TabIndex = 3;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(40, 175);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(240, 150);
			this->grilla->TabIndex = 4;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->grilla2->Location = System::Drawing::Point(484, 19);
			this->grilla2->Name = L"grilla2";
			this->grilla2->Size = System::Drawing::Size(240, 150);
			this->grilla2->TabIndex = 5;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Column3";
			this->Column3->Name = L"Column3";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(403, 79);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 6;
			this->button3->Text = L"Concatenar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(72, 48);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(35, 13);
			this->label1->TabIndex = 7;
			this->label1->Text = L"label1";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(72, 89);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(35, 13);
			this->label2->TabIndex = 8;
			this->label2->Text = L"label2";
			// 
			// txtinsertar
			// 
			this->txtinsertar->Location = System::Drawing::Point(129, 124);
			this->txtinsertar->Name = L"txtinsertar";
			this->txtinsertar->Size = System::Drawing::Size(100, 20);
			this->txtinsertar->TabIndex = 9;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(244, 122);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 10;
			this->button1->Text = L"Insertar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grilla1->Location = System::Drawing::Point(295, 175);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(240, 150);
			this->grilla1->TabIndex = 11;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(269, 144);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 12;
			this->button2->Text = L"insertar2";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// txtinsertar2
			// 
			this->txtinsertar2->Location = System::Drawing::Point(350, 144);
			this->txtinsertar2->Name = L"txtinsertar2";
			this->txtinsertar2->Size = System::Drawing::Size(100, 20);
			this->txtinsertar2->TabIndex = 13;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(714, 382);
			this->Controls->Add(this->txtinsertar2);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtinsertar);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txttam2);
			this->Controls->Add(this->txttam1);
			this->Controls->Add(this->btntamano2);
			this->Controls->Add(this->btntamano1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btntamano1_Click(System::Object^  sender, System::EventArgs^  e) {

				 int tam1;
				 tam1=System::Convert::ToInt32(txttam1->Text);

				 grilla->RowCount=tam1;


			 }
private: System::Void btntamano2_Click(System::Object^  sender, System::EventArgs^  e) {



			 int tam2;
			 tam2=System::Convert::ToInt32(txttam2->Text);
			 grilla1->RowCount=tam2;

		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {


			 int ele;
			 ele=System::Convert::ToInt32(txtinsertar->Text);
			 V1.Set_Vector1(pos,ele);
			 grilla->Rows[pos]->Cells[0]->Value=ele;
			 pos++;
			 

		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {

			 int tam1,tam2,tam 3;

			  tam1=System::Convert::ToInt32(txttam1->Text);
			   tam2=System::Convert::ToInt32(txttam2->Text);

			   tam3= tam1+tam2;
			   C1.concatenar();


		 }




private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {

			 	 int ele;
			 ele=System::Convert::ToInt32(txtinsertar2->Text);
			 V2.Set_Vector2(ele);
			 grilla1->Rows[pos2]->Cells[0]->Value=ele;
			 pos2++;
		 }
};
}

