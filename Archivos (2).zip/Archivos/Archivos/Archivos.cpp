// Archivos.cpp : main project file.

#include "stdafx.h"

#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.cpp"

using namespace std;


void main() {
	int opc= 0;
	ABMamigo *amig = new ABMamigo("amigOO.dat");

	do
	{cout<<"1.adicionar Nuevo"<<endl;
	cout<<"2.listar"<<endl;
	cout<<"3.buscarReg"<<endl;
	cout<<"4.eliminarReg" <<endl;
	cout <<"5.modificarReg"<<endl;
	cout <<"6.listar"<<endl;
	cout <<"Opcion:";
	cin>>opc;  
	switch(opc){
	case 1:
		amig->adicionarNuevo();
		break;
	case 2:
		amig->listar();
		break;
	case 3:
			amig->buscarReg();
			break;
    case 4:
	amig->eliminarReg();
			break;
    case 5:
	amig->modificarReg();
		break;
    case 6:

	amig->listar();
		break;

	}
	
	/*cout << "Ingrese una Opcion:";*/
	//cin>>opc;  
}while(opc!=6);
getch();
}