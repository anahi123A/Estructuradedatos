#pragma once
#define MAX 10
#define N  10
#include <string>
#include "iostream"
class Vector
{
private:

	char vector[N];

	int tamano;
public:
	Vector(void);
	~Vector(void);

	int Get_tamano();
	void Set_tamano(int tam);

	char  Get_vector(int posicion);
	void Set_vector( char elemento, int posicion);

	Vector intercambiar(char vector1, char vector2,int posicion);
};

