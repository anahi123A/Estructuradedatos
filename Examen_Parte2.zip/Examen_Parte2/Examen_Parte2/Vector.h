#pragma once
#define MAX 10
#include <string>
#include "iostream"
using namespace std;
class Vector
{
private:

	string vector1[MAX];
	int vector[MAX];
	int tamano;
public:
	Vector(void);
	~Vector(void);

	int Get_tamano();
	void Set_tamano(int tam);

	string Get_vector(int posicion);
	void Set_vector(  int posicion, int elemento);
	void Incrementar();
	void Decrementar();


	void intercambiar();
};

