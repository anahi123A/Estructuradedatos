#pragma once
#include "Vector.h"
#include <string>
#include <msclr\marshal_cppstd.h>
namespace Examen_Parte2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	Vector vector1, vector2;
	int posicion =0;
		int posicion1 =0;
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtTamano1;
	private: System::Windows::Forms::TextBox^  txtdato1;


	private: System::Windows::Forms::DataGridView^  grilla2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  btnInter;

	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::TextBox^  txtTamano2;
	private: System::Windows::Forms::TextBox^  txtdato2;



	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtTamano1 = (gcnew System::Windows::Forms::TextBox());
			this->txtdato1 = (gcnew System::Windows::Forms::TextBox());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btnInter = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->txtTamano2 = (gcnew System::Windows::Forms::TextBox());
			this->txtdato2 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(35, 42);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(35, 69);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(40, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"String1";
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla1->Location = System::Drawing::Point(12, 111);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(273, 172);
			this->grilla1->TabIndex = 2;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Dato1";
			this->Column1->Name = L"Column1";
			// 
			// txtTamano1
			// 
			this->txtTamano1->Location = System::Drawing::Point(95, 39);
			this->txtTamano1->Name = L"txtTamano1";
			this->txtTamano1->Size = System::Drawing::Size(100, 20);
			this->txtTamano1->TabIndex = 3;
			// 
			// txtdato1
			// 
			this->txtdato1->Location = System::Drawing::Point(95, 69);
			this->txtdato1->Name = L"txtdato1";
			this->txtdato1->Size = System::Drawing::Size(100, 20);
			this->txtdato1->TabIndex = 4;
			this->txtdato1->TextChanged += gcnew System::EventHandler(this, &Form1::textBox2_TextChanged);
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grilla2->Location = System::Drawing::Point(325, 111);
			this->grilla2->Name = L"grilla2";
			this->grilla2->Size = System::Drawing::Size(267, 172);
			this->grilla2->TabIndex = 5;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Dato2";
			this->Column2->Name = L"Column2";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(230, 32);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 6;
			this->button1->Text = L"Definir";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(230, 67);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 7;
			this->button2->Text = L"Ingresar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// btnInter
			// 
			this->btnInter->Location = System::Drawing::Point(598, 111);
			this->btnInter->Name = L"btnInter";
			this->btnInter->Size = System::Drawing::Size(75, 23);
			this->btnInter->TabIndex = 8;
			this->btnInter->Text = L"Intercambiar";
			this->btnInter->UseVisualStyleBackColor = true;
			this->btnInter->Click += gcnew System::EventHandler(this, &Form1::btnInter_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(539, 63);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 14;
			this->button4->Text = L"Ingresar";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(539, 28);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 23);
			this->button5->TabIndex = 13;
			this->button5->Text = L"Definir";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// txtTamano2
			// 
			this->txtTamano2->Location = System::Drawing::Point(410, 35);
			this->txtTamano2->Name = L"txtTamano2";
			this->txtTamano2->Size = System::Drawing::Size(100, 20);
			this->txtTamano2->TabIndex = 12;
			// 
			// txtdato2
			// 
			this->txtdato2->Location = System::Drawing::Point(410, 69);
			this->txtdato2->Name = L"txtdato2";
			this->txtdato2->Size = System::Drawing::Size(100, 20);
			this->txtdato2->TabIndex = 11;
			this->txtdato2->TextChanged += gcnew System::EventHandler(this, &Form1::textBox4_TextChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(344, 65);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(40, 13);
			this->label3->TabIndex = 10;
			this->label3->Text = L"String2";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(344, 38);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(46, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Tama�o";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(676, 351);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->txtTamano2);
			this->Controls->Add(this->txtdato2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->btnInter);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->txtdato1);
			this->Controls->Add(this->txtTamano1);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				  int tam;
				 tam=Convert::ToInt32(txtTamano1->Text);
				 grilla1->RowCount=tam;
			 }
private: System::Void textBox4_TextChanged(System::Object^  sender, System::EventArgs^  e) {

		 }
private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			   int tam;
				 tam=Convert::ToInt32(txtTamano2->Text);
				 grilla2->RowCount=tam;
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			string letra1 ;
	letra1=System::Convert::ToString(txtdato1->Text);
			 vector1.Set_vector(posicion,letra1);
			 grilla1->Rows[posicion]->Cells[0]->Value=letra1;
			 posicion++;
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 string letra2;
				letra2=Convert::ToString(txtdato2->Text);
			 vector2.Set_vector(posicion1,letra2);
			 grilla2->Rows[posicion1]->Cells[0]->Value=letra2;
			 posicion1++;
		 }
private: System::Void btnInter_Click(System::Object^  sender, System::EventArgs^  e) {


			 
		
		 }
};
}

