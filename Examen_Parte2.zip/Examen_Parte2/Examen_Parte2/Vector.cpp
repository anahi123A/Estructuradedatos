#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{//ctor1[MAX]=//Hola","Adios","Chau","Bye");
vector[N]=0;
//A","B","C","D","E");
tamano=0;

}
int Vector::Get_tamano()
	{return tamano;
	}
void Vector::Set_tamano(int tam)
	{tamano= tam;
	}

	char Vector::Get_vector(int posicion)
	{return vector[posicion];}

void Vector::Set_vector( char elemento,int posicion)
	{ vector[posicion]= elemento;
	
	}


Vector Vector::intercambiar(char vector1, char vector2,int posicion)
	{
	int i;
	char  inter;
	for(i=0; i <=posicion ; i++ )
	{inter<= vector1[i];
	vector1[i]=vector2[i];
	vector2[i]=vector1[i];
	}
	
	}
	