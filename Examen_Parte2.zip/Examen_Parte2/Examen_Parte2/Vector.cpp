#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#include <string>
#define MAX 10
using namespace std;

Vector::Vector(void)
{
vector1[MAX]=" ";
vector[MAX]=0;
tamano=0;

}
int Vector::Get_tamano()
	{return tamano;
	}
void Vector::Set_tamano(int tam)
	{tamano= tam;
	}

string Vector::Get_vector(int posicion)
	{return vector1[posicion];}

void Vector::Set_vector(int posicion,  int elemento)
	{ vector[posicion]= elemento;
	
	}

void Vector::Incrementar()
{tamano++;}

void Vector::Decrementar()
{tamano--;}


void Vector::intercambiar()
	{
	int i;
	int posicicion;
	string vector1,vector2;
	string  inter[i]=" ";
	for(i=0; i <=posicion ; i++ )
	{if(inter <vector2[i]);
	{inter=vector1[i];
	vector1[i]=vector2[i];
	vector2[i]=inter[i];}
	}
	
}
	