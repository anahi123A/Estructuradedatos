#pragma once
#include "Vector.h"
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>

namespace generarvec {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;


	Vector vector1,vector2;
	int posicion=0;
	int posicion1=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label4;
	protected: 
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtPalabra1;
	private: System::Windows::Forms::TextBox^  txtTamano1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtPalabra;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnDefinir;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtPalabra1 = (gcnew System::Windows::Forms::TextBox());
			this->txtTamano1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtPalabra = (gcnew System::Windows::Forms::TextBox());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(290, 65);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(43, 13);
			this->label4->TabIndex = 27;
			this->label4->Text = L"Palabra";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(290, 36);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(46, 13);
			this->label3->TabIndex = 26;
			this->label3->Text = L"Tama�o";
			// 
			// txtPalabra1
			// 
			this->txtPalabra1->Location = System::Drawing::Point(351, 65);
			this->txtPalabra1->Name = L"txtPalabra1";
			this->txtPalabra1->Size = System::Drawing::Size(100, 20);
			this->txtPalabra1->TabIndex = 25;
			// 
			// txtTamano1
			// 
			this->txtTamano1->Location = System::Drawing::Point(351, 35);
			this->txtTamano1->Name = L"txtTamano1";
			this->txtTamano1->Size = System::Drawing::Size(100, 20);
			this->txtTamano1->TabIndex = 24;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(481, 72);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 23;
			this->button1->Text = L"Ingresar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grilla1->Location = System::Drawing::Point(210, 101);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(257, 170);
			this->grilla1->TabIndex = 22;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Palabra";
			this->Column2->Name = L"Column2";
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(-71, 101);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(240, 170);
			this->grilla->TabIndex = 21;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Palabra";
			this->Column1->Name = L"Column1";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(-90, 72);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(43, 13);
			this->label2->TabIndex = 20;
			this->label2->Text = L"Palabra";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(-90, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 19;
			this->label1->Text = L"Tama�o";
			// 
			// txtPalabra
			// 
			this->txtPalabra->Location = System::Drawing::Point(-17, 65);
			this->txtPalabra->Name = L"txtPalabra";
			this->txtPalabra->Size = System::Drawing::Size(100, 20);
			this->txtPalabra->TabIndex = 18;
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(-17, 33);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(100, 20);
			this->txtTamano->TabIndex = 17;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(481, 33);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 16;
			this->button3->Text = L"Definir";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(138, 62);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 15;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(138, 33);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 14;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(705, 354);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtPalabra1);
			this->Controls->Add(this->txtTamano1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtPalabra);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {

				int tam1;
			 tam1=System::Convert::ToInt32(Text->txtTamano);
			 grilla->RowCount=tam1;
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			char palabra;
			 palabra=System::Convert::ToString(Text->txtPalabra);
			 vector1.Set_vector(palabra,posicion);
			 grilla->Rows[posicion]->Cells[0]->Value=palabra;
			 posicion++;
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {

			  int tam2
			 tam2=System::Convert::ToInt32(Text->txtTamano1);
			 grilla1->RowCount=tam2;
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

			 char palabra1;
			 palabra1=System::Convert::ToString(Text->txtPalabra1);
			 vector2.generar(posicion1);
			 grilla1->Rows[posicion1]->Cells[0]->Value=palabra1;
			 posicion1++;

		 }
};
}

