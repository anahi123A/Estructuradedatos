#include "StdAfx.h"
#include "Vector.h"

Vector::Vector(void)
{vector[N]= '';

	int tamano=0;
}
	
	Vector::~Vector(void)
		{
}
	int Vector::Get_tamano()
		{
			return tamano;
}
	void Vector::Set_tamano(int tam)
		{ tamano=tam;

}
 char Vector::Get_vector(int posicion)
 {return vector[posicion.at];
}
	void Vector::Set_vector(char palabra, int posicion)
	{ vector[posicion]= palabra;
}
		void Vector::generar(int posicion)
			{ int i;
		string generar;
				char vector='';
				for(i=0;i<posicion; i++)
				{
					generar=vector.at(i);
					
				}
				for(i=vector.at(0);i<4; i++)
				{
				generar=vector.at(0)+vector.at(i);
				}
			
}