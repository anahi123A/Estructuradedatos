#pragma once
#include"iostream"
using namespace std;
#include  <string>
#define N 10
#define M 10
class Vector
{private:

string vector[N];
	
	int tamano;
public:
	Vector(void);
	~Vector(void);
	int Get_tamano();
	void Set_tamano(int tam);
	char Get_vector(int posicion);
	void Set_vector(char palabra, int posicion);
	void generar(int posicion);
};

