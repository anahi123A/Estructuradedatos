#include "StdAfx.h"
#include "Vetor.h"
#define MAX 10
using namespace std;

Vetor::Vetor(void)
{vetor[MAX]=0;
tamano=0;

}
	Vetor::~Vetor(void)
	{}
	int Vetor::Get_tamano()
	{return tamano;}
	void Vetor::Set_tamano(int tam)
	{tamano = tam;}

	int Vetor::Get_vetor(int posicion)
	{return vetor[posicion];}
	void Vetor::Set_vetor(char nombre, int posicion)
	{vetor[posicion]=nombre; }
	void Vetor::generarvec(int vetor, int posicion)
	{}