//profe la primera parte del examen me toco el ejercciio 40 y no lo pude acabar no me dio tiempo y no pude guardar ese dia mi programa
//por lo que alguanas cosas estan diferentes pero  es lo que mme acuerdo que puse pero solo hice eso por el tiempo porque mi computadora estaba lenta  
#pragma once
#define MAX 10
using namespace std;
#include <iostream>
#include <string>

 class Vetor
{

private:
	int vetor[MAX];
	int tamano,
public:
	Vetor(void);
	~Vetor(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_vetor(int posicion);
	void Set_vetor(char dato, int posicion);
	void generarvec(int vetor, int posicion);

};

