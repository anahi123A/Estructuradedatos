#pragma once
#include <iostream>
#include <string>

using namespace std;

class Cuenta
{
protected:
	double tipoDeInteres;
	double saldo;
	string cuenta;
	string nombre;
public:
	Cuenta();
	void Set_Nombre(string nom);
	void Set_Saldo(double s);
	void Set_Cuenta(string cue);
	void Set_TipoDeInteres(double tipo);
	string Get_Nombre();
	string Get_Cuenta();
	double Get_TipoDeInteres();
	double estado();
	void reintegro(double cantidad);
	void ingreso(double cantidad);

};

