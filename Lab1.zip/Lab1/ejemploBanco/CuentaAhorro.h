#pragma once
#include "Cuenta.h"
#include <iostream>
#include <string>
using namespace std;
class CuentaAhorro:public  Cuenta  //CuentaAhorro es una subclase de Cuenta
{
private:
double cuotaMantenimiento;

public:
	CuentaAhorro();
	void Set_CuotaManten(double cantidad);
	double Get_CuotaManten();
	void reintegro(double cantidad);  //El metodo de la subclase se ejecuta sobre la del padre
};

