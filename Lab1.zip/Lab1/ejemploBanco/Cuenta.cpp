#include "StdAfx.h"
#include "Cuenta.h"


Cuenta::Cuenta()
{
}
void Cuenta::Set_Nombre(string nom)
{
	nombre=nom;
}
void Cuenta::Set_Cuenta(string cue)
{
	cuenta=cue;
}
void Cuenta::Set_TipoDeInteres(double tipo)
{
	tipoDeInteres=tipo;
}
string Cuenta::Get_Nombre()
{
	return nombre;
}
string Cuenta::Get_Cuenta()
{
	return cuenta;
}
double Cuenta::Get_TipoDeInteres()
{
	return tipoDeInteres;
}
double Cuenta::estado()
{
	return saldo;
}
void Cuenta::reintegro(double cantidad)
{
	saldo=saldo-cantidad;
}
void Cuenta::ingreso(double cantidad)
{
	saldo=saldo+cantidad;
}

void Cuenta:: Set_Saldo(double s)
{
saldo=s;
}